<template>
  <div id="app" class="text-14">
    <transition name="fade" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>
<script>
import FastClick from 'fastclick'
FastClick.attach(document.body)

export default {
  name: 'app',
  mounted () {
    this.$Progress.finish()
  },
  data () {
    return {}
  },
  created () {
    // 用户行为分析
    if (process.env.NODE_ENV !== 'development') {
      this.$utils.loadScript(this.$link.PWIK_TP);
      this.$utils.loadScript(this.$link.PWIK_EVENT);
    }
    // 加载进度条
    this.$Progress.start()
    this.$router.beforeEach((to, from, next) => {
      if (to.meta.progress !== undefined) {
        let meta = to.meta.progress
        this.$Progress.parseMeta(meta)
      }
      this.$Progress.start()
      next()
    })
    this.$router.afterEach((to, from) => {
      this.$Progress.finish()
    })
  }
}
</script>

<style lang="less">
@import "~assets/styles/app";
@import "~assets/styles/reset";
@import "~assets/styles/mixins";
@import "~assets/styles/style";
@import "~assets/styles/layout.css";
@import "~assets/styles/baseTheme.css";
</style>


<template>
  <section>
    <div v-if="!supportedCards.length" class="bg-white text-center" style="padding-top: 1rem;padding-bottom: .7rem;">
      <img style="width:1.62rem;" src="~assets/images/quickPay/icon_empty.png" alt="">
      <div class="text-13 text-gray-9" style="line-height: .7rem;">您暂无可绑定快捷支付的卡片</div>
    </div>
    <div v-if="supportedCards.length">
      <div class="text-gray-9 text-center my-10 text-13">选择需绑定快捷支付的卡片</div>
      <div v-for="(it, i) in supportedCards" :key="i" class="text-14 mx-16 bg-white p-20 mb-15 center_space-between" @click="onSelectCard(it)">
        <div class="flex">
          <img style="width: .8rem; height: .8rem;" src="~assets/images/common/logo_citic.png" alt="">
          <div class="ml-8" style="width:4rem;">
            <div class="text-14">{{it.cardName}}</div>
            <div class="text-16 mt-5 space-between">
              <div>{{it.cardNo.slice(0, 4)}}</div>
              <div>****</div>
              <div>****</div>
              <div>{{it.cardNo.slice(-4)}}</div>
            </div>
          </div>
        </div>
        <img style="width: .14rem; height: .25rem;" src="~assets/images/common/arrow_right.png" alt="">
      </div>
    </div>
    <div v-if="unsupportedCards.length" class="text-gray-9">
      <div class="text-13 py-10 center_center">
        <div class="divide-line mr-8"></div>
        <div>以下卡片不可选择</div>
        <div class="divide-line ml-8"></div>
      </div>
      <div v-for="(it, i) in unsupportedCards" :key="i" class="text-14 mx-16 bg-white p-20 mb-15 flex">
        <img style="width: .8rem; height: .8rem;" src="~assets/images/common/logo_citic.png" alt="">
        <div class="ml-8">
          <div class="text-14">{{it.cardName}}</div>
          <div class="text-16 mt-5 space-between" style="width:4rem;">
            <div>{{it.cardNo.slice(0, 4)}}</div>
            <div>****</div>
            <div>****</div>
            <div>{{it.cardNo.slice(-4)}}</div>
          </div>
        </div>
      </div>
      <div class="mx-16 text-13 mb-15">外币单标卡片、未激活卡片、异常无效卡片等不支持快捷绑定支付业务</div>
    </div>
  </section>
</template>
<script>

export default{
  name: 'cardList',
  data () {
    return {
      cardList: []
    }
  },
  created () {
    this.$ui.header.setHeader({title: '快捷支付', showClose: true});
    const {cardNo} = this.$route.query;
    cardNo && this.$router.push({path: '/insts', query: this.$route.query});
    this.init();
  },
  computed: {
    supportedCards () {
      return this.cardList.filter(v => v.status);
    },
    unsupportedCards () {
      return this.cardList.filter(v => !v.status);
    }
  },
  methods: {
    init () {
      this.loadCardList();
    },
    loadCardList () {
      setTimeout(() => {
        this.cardList = [
          {cardName: '中信淘宝联名卡淘气版金卡', cardNo: '6226123456788866', status: 1},
          {cardName: '中信淘宝联名卡淘气版金卡', cardNo: '6226123456788866', status: 1},
          {cardName: '中信淘宝联名卡淘气版金卡', cardNo: '6226123456788866', status: 0},
          {cardName: '中信淘宝联名卡淘气版金卡', cardNo: '6226123456788866', status: 0}
        ];
      }, 300);
    },
    onSelectCard (card) {
      card.cardNo && this.$router.push({path: '/insts', query: {cardNo: card.cardNo}});
    }
  }
}
</script>

<style scoped>
  .divide-line {
    height: 0;
    width: .54rem;
    border-top: .02rem solid #999;
  }
</style>


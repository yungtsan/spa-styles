<template>
  <section>
    <div class="pl-16 bg-white">
      <div v-for="(it, i) in bindingList" :key="i" :class="['center_space-between pr-16', i ? 'bt-solid-d' : '']">
        <div style="height: 1rem;" class="align-center">
          <img style="width:.44rem;height:.44rem;" :src="iconMap[it.channel]" alt="">
          <div class="ml-10">{{instNameMap[it.channel]}}</div>
        </div>
        <div :class="['text-12 align-center', it.status ? 'text-gray-9' : 'text-red']" @click="onBindPay(it)">
          <div>{{it.status ? '已绑定' : it.marketingInfo}}</div>
          <img style="width:.14rem;height:.25rem;margin-left:.16rem;" v-if="!it.status" src="~assets/images/common/arrow_right.png" alt="">
        </div>
      </div>
    </div>
    <div class="p-16 text-gray-9 text-13">
      <div>点击绑定以上任意支付机构，即表明同意<span @click="onViewAgreement" class="text-blue">《中信银行信用卡快捷支付绑卡服务协议》</span></div>
      <div class="mt-15">
        <div>温馨提示：</div>
        <div>1. 如您后续需要解除绑定，请登录第三方支付平台操作。</div>
        <div>2. 以上营销活动细则，请查阅中信银行信用卡官网。</div>
      </div>
    </div>
  </section>
</template>

<script>
import iconAlipay from 'assets/images/quickPay/icon_alipay.png';
import iconJD from 'assets/images/quickPay/icon_jd.png';
import iconMeituan from 'assets/images/quickPay/icon_meituan.png';
import iconWechat from 'assets/images/quickPay/icon_wechat.png';

export default{
  name: 'institutions',
  data () {
    return {
      bindingList: [],
      iconMap: {
        alipay: iconAlipay,
        jd: iconJD,
        meituan: iconMeituan,
        wechat: iconWechat
      },
      instNameMap: {
        alipay: '支付宝',
        jd: '京东支付',
        meituan: '美团支付',
        wechat: '微信支付'
      }
    }
  },
  created () {
    this.$ui.header.setHeader({title: '快捷支付', showClose: true});
    this.init();
  },
  methods: {
    init () {
      this.loadInstBindings();
    },
    loadInstBindings () {
      setTimeout(() => {
        this.bindingList = [
          {channel: 'alipay', status: 1, marketingInfo: ''},
          {channel: 'jd', status: 0, marketingInfo: '绑定返20元刷卡金'},
          {channel: 'meituan', status: 1, marketingInfo: ''},
          {channel: 'wechat', status: 1, marketingInfo: ''}
        ];
      }, 300);
    },
    onViewAgreement () {
      window.location.href = this.$link.QUICKPAY_BINDING_AGREEMENT;
    },
    onBindPay (channel) {
      if (!channel.status) {
        this.$ui.toast.show('开发中，敬请期待')
      }
    }
  }
}
</script>

<style>
.text-red {
  color: #F00036;
}
.text-blue {
  color: #12aafe;
}
</style>


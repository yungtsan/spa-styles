import Vue from 'vue'
import Router from 'vue-router'
import cardList from '../pages/cardList'
import instList from '../pages/instList'
Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/',
      redirect: '/index'
    },
    {
      path: '/index',
      name: 'index',
      component: cardList
    },
    {
      path: '/insts',
      name: 'institutions',
      component: instList
    }
  ]
})

// 默认先进的路由
export default router

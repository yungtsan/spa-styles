// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './pages/App'
import MaskPlugin from 'plugins/Mask/index'
import LoadingPlugin from 'plugins/Loading/index'
import DialogPlugin from 'plugins/Dialog/index'
import Toast from 'plugins/Toast/index'
import Header from 'plugins/Header/index'
import C from 'utils/common'
import router from './router'
import VueProgressBar from 'vue-progressbar'
import Promise from 'promise-polyfill'

/* eslint-disable */
if (process.env.NODE_ENV === 'UAT') {
  let VConsole = require('../../../static/vconsole.min')
  new VConsole();
}

/* eslint-disable no-new */
Vue.use(C)
Vue.use(MaskPlugin)
Vue.use(LoadingPlugin)
Vue.use(DialogPlugin)
Vue.use(Toast)
Vue.use(Header)
Vue.use(VueProgressBar, {
  color: 'rgb(255, 81, 84)',
  failedColor: 'blue',
  thickness: '0.02rem'
})
new Vue({
  el: '#app',
  router,
  created () {
    if (!window.Promise) {
      window.Promise = Promise;
    }
  },
  template: '<App/>',
  components: { App }
})

import Vue from 'vue'
import Router from 'vue-router'
import pushSetting from '../pages/pushSetting'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/pushSetting',
      name: 'pushSetting',
      component: pushSetting
    }
  ]
})

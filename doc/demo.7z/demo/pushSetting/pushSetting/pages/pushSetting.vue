<template>
  <div class="pushaccount text-14">
    <div class="accounts" v-if="accounts.length">
      <div v-for="it in accounts" :key="it.grupId">
        <div class="p-12 bb-solid-d">{{typeMapping[it.grupType]}}</div>
        <div :class="['p-12 bg-white center_space-between', (it.sendStatus === 'Y' && it.grupStatus === 'Y') ? 'bb-solid-e' : 'bb-solid-d']">
          <div>交易提醒</div>
          <div @click="onToggleStatus(it)">
            <div :class="['account_bg align-center', it.sendStatus === 'Y' & it.grupStatus === 'Y' ? 'bg-green flex-end' : 'bg-gray flex-start']">
              <div class="account_btn bg-white inline-block"></div>
            </div>
          </div>
        </div>
        <div v-if="it.sendStatus === 'Y' & it.grupStatus === 'Y'" class="p-12 bg-white center_space-between bb-solid-d" @click="onSetLimit(it)">
          <div>起始金额</div>
          <div class="align-center">
            <div>{{it.sendAmt === '0.00' ? '不限' : it.sendAmt + '元以上'}}</div>
            <img class="icon_arrow-right ml-10" src="../../../assets/images/c.png" alt="">
          </div>
        </div>
      </div>
    </div>
    <div v-if="shouldShowEmptyInfo" class="p-12 bg-white text-14 text-center">您尚未绑定公众号</div>
    <div :class="['mt-16 p-12 bg-white center_space-between', promotionPushAccepted ? 'bb-solid-e' : 'bb-solid-d']">
      <div>接收活动类通知</div>
      <div @click="onTogglePromotionMsgStatus">
        <div :class="['account_bg align-center', promotionPushAccepted ? 'bg-green flex-end' : 'bg-gray flex-start']">
          <div class="account_btn bg-white inline-block"></div>
        </div>
      </div>
    </div>
    <div class="bb-solid-d" v-if="moreAccounts.length">
      <div class="p-12 bb-solid-d">{{shouldShowEmptyInfo ? '推荐关注公众号' : '更多公众号'}}</div>
      <div v-for="(it, i) in moreAccounts" :key="i" :class="['guide align-center bg-white px-12 py-5', i ? 'bt-solid-e' : '']">
        <div class="mr-10"><img class="guide_icon" :src="it.icon" alt="ICON"></div>
        <div class="text-12">
          <div>{{it.label}}</div>
          <div>{{it.entry}}</div>
        </div>
      </div>
    </div>
    <ActionSheet v-if="shouldShowActionSheet" :options="limitOptions" @onSelect="onActionSheetSelect" @onCancel="onHideActionSheet"/>
  </div>
</template>

<script>
import iconWechat from '../../../assets/images/wx.png';
import iconAlipay from '../../../assets/images/zfb.png';
import iconQQ from '../../../assets/images/qq.png';
import {ActionSheet} from 'components/ActionSheet';
import * as Utils from 'utils/utils'

const typeMapping = {
  IDWX: '微信服务号',
  IDZF: '支付宝生活号',
  IDQQ: '手机QQ公众号'
};
Utils.isNewcore && (typeMapping.DKKJ = '动卡空间APP');

export default {
  components: {
    ActionSheet
  },
  data () {
    return {
      shouldShowEmptyInfo: false,
      shouldShowActionSheet: false,
      promotionPushAccepted: true,
      accountList: [ // 所有公众号列表、配置
        {label: '微信服务号', code: 'IDWX', icon: iconWechat, entry: ['微信', '添加朋友', '公众号', '搜索 中信银行信用卡'].join(' - ')},
        {label: '支付宝生活号', code: 'IDZF', icon: iconAlipay, entry: ['支付宝', '添加朋友', '生活号', '搜索 中信银行信用卡'].join(' - ')},
        {label: '手机QQ公众号', code: 'IDQQ', icon: iconQQ, entry: ['手机QQ', '添加朋友', '找公众号', '搜索 中信银行信用卡'].join(' - ')}
      ],
      accounts: [], // 用户已绑定的公众号
      moreAccounts: [], // 用户未绑定的公众号
      typeMapping: {...typeMapping},
      limitOptions: [
        {text: '不限'},
        {text: '200元以上'},
        {text: '500元以上'},
        {text: '1000元以上'}
      ],
      limitValues: ['0.00', '200.00', '500.00', '1000.00']
    }
  },
  created () {
    this.$ui.header.setHeader({title: '推送设置'});
    this.loadData();
    this.queryPromotionMsgStatus();
  },
  methods: {
    loadData () {
      this.$http.get(this.$api.GET_PUBLIC_ACCOUNT, (res) => {
        if (res.retCode === '00') {
          this.accounts = (res.publicAccounts || []).filter(v => this.typeMapping[JSON.parse(v).grupType]).map(item => JSON.parse(item));
          !this.accounts.length && (this.shouldShowEmptyInfo = true);
          // 更多公众号；本页面的操作不会引起变化，无需自动计算
          !this.moreAccounts.length && (this.moreAccounts = this.accountList.filter(v => !this.accounts.find(vv => v.code === vv.grupType)));
        } else {
          this.$ui.toast.show(res.retMsg);
        }
      });
    },
    queryPromotionMsgStatus () {
      this.$http.get(this.$api.QUERY_PROMOTION_MSG_STATUS, res => {
        if (res.retCode === '000000') {
          this.promotionPushAccepted = res.data.status === 'Y';
        } else {
          this.$ui.toast.show(res.retMsg);
        }
      })
    },
    // 设置开启/关闭交易提醒
    onToggleStatus (account) {
      const {grupId, grupType, sendAmt, grupStatus} = account;
      const actType = grupStatus === 'Y' ? '01' : '00';
      this.updateAccountInfo({actType, grupId, grupType, sendAmt});
    },
    // 设置提醒起始金额/限额
    onSetLimit (account) {
      this.shouldShowActionSheet = true;
      // 记录操作中的公众号
      this.operatingAccount = account;
    },
    onActionSheetSelect (index) {
      this.shouldShowActionSheet = false;
      const {grupId, grupType, sendAmt} = this.operatingAccount;
      const updatedSendAmt = this.limitValues[index];
      if (updatedSendAmt !== sendAmt) {
        this.updateAccountInfo({actType: '03', grupId, grupType, sendAmt: updatedSendAmt});
      }
    },
    updateAccountInfo (params) {
      const actType = params.actType;
      const msgMapping = {
        '00': '开启成功',
        '01': '关闭成功',
        '03': '设置成功'
      };
      this.$http.post(this.$api.SETTING_PUBLIC_ACCOUNT, params, (res) => {
        if (res.retCode === '00') {
          this.$ui.toast.show(msgMapping[actType]);
          this.loadData();
        } else {
          this.$ui.toast.show(res.retMsg);
        }
      });
    },
    onHideActionSheet () {
      this.shouldShowActionSheet = false;
    },
    onTogglePromotionMsgStatus () {
      this.$http.post(this.$api.UPDATE_PROMOTION_MSG_STATUS, {
        status: this.promotionPushAccepted ? 'N' : 'Y'
      }, res => {
        if (res.retCode === '000000') {
          this.promotionPushAccepted = !this.promotionPushAccepted;
        } else {
          this.$ui.toast.show(res.retMsg);
        }
      });
    }
  }
}
</script>

<style scoped>
.bg-white {
  background-color: white;
}
.icon_arrow-right {
  width: .16rem;
  height: .26rem;
}
.bb-solid-e {
  border-bottom: 1px solid #eee;
}
.bb-solid-d {
  border-bottom: 1px solid #ddd;
}
.bt-solid-e {
  border-top: 1px solid #eee;
}
.inline-block {
  display: inline-block;
}
.account_bg {
  width: 1rem;
  height: 0.54rem;
  border-radius: .5rem;
  border: 1px solid #eee;
}
.account_btn {
  width: 0.5rem;
  height: 0.5rem;
  margin: .01rem;
  border-radius: 50%;
}
.bg-green {
  background-color: #5ebd09;
}
.bg-gray {
  background-color: #ddd;
}
.flex-end {
  flex-direction: row-reverse;
}
.flex-start {
  flex-direction: row;
}
.guide {
  height: 1rem;
}
.guide_icon {
  width: .6rem;
  height: .6rem;
}
</style>

<template>
  <div id="app">
    <transition name="fade" mode="out-in">
       <router-view></router-view>
    </transition>
    <vue-progress-bar></vue-progress-bar>
  </div>
</template>
<script>
import FastClick from 'fastclick'
FastClick.attach(document.body)

export default {
  name: 'app',
  mounted () {
    this.$Progress.finish()
  },
  created () {
    this.$Progress.start()
    this.$router.beforeEach((to, from, next) => {
      if (to.meta.progress !== undefined) {
        let meta = to.meta.progress
        this.$Progress.parseMeta(meta)
      }
      this.$Progress.start()
      next()
    })
    this.$router.afterEach((to, from) => {
      this.$Progress.finish()
    })
  }
}
</script>
<style lang="less">
@import "~assets/styles/app";
@import "~assets/styles/reset";
@import "~assets/styles/mixins";
@import "~assets/styles/style";
@import "~assets/styles/icon";
@import "~assets/css/layout.css";
</style>
